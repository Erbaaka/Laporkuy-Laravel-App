<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class KategoriLaporanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        \App\Models\KategoriLaporan::insert([
            ['nama' => 'Jalan Rusak'],
            ['nama' => 'Lampu Jalan Mati'],
            ['nama' => 'Sampah Menumpuk'],
            ['nama' => 'Genangan Air'],
        ]);
    }
}
