import './bootstrap';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();

document.addEventListener("alpine:init", () => {
    document.addEventListener("scroll", function () {
        const navbar = document.getElementById("navbar");

        if (!navbar) return;

        if (window.scrollY > 50) {
            navbar.classList.remove("bg-white");
            navbar.classList.add("bg-gray-100", "shadow");
        } else {
            navbar.classList.add("bg-white");
            navbar.classList.remove("bg-gray-100", "shadow");
        }
    });
});

