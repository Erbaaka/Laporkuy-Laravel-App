@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto p-4">
    <h1 class="text-xl font-bold mb-4">Laporan Saya</h1>

    @if(session('success'))
        <div class="bg-green-100 text-green-800 p-2 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <a href="{{ route('laporan.create') }}" class="bg-blue-600 text-white px-4 py-2 rounded mb-4" style="background-color: #3B82F6 !important; color: white !important;">
        + Buat Laporan Baru
    </a>
    <hr class="mb-4">
    <h2 class="text-xl font-semibold mb-2">Daftar Laporan Anda</h2>
    <hr class="mb-4">

    @if($laporans->count() > 0)
        <div class="space-y-4">
            @foreach($laporans as $laporan)
                <div class="border p-4 rounded shadow">
                    <h2 class="text-lg font-semibold">{{ $laporan->judul }}</h2>
                    <p class="text-sm text-gray-600 mb-1">
                        Kategori: {{ $laporan->kategori->nama }} | Lokasi: {{ $laporan->lokasi }}
                    </p>
                    <p class="mb-2">{{ $laporan->deskripsi }}</p>
                    @if($laporan->foto)
                        <img src="{{ asset('storage/' . $laporan->foto) }}" alt="Foto Laporan" class="w-32 mb-2">
                    @endif
                    <p class="text-sm font-semibold">
                        Status: 
                        @if($laporan->status === 'baru')
                            <span class="text-yellow-600">Baru</span>
                        @elseif($laporan->status === 'diproses')
                            <span class="text-blue-600">Diproses</span>
                        @else
                            <span class="text-green-600">Selesai</span>
                        @endif
                    </p>
                    <div class="flex items-center space-x-10 mt-2">
                        <a href="{{ route('laporan.edit', $laporan->id) }}" class="text-blue-500 hover:underline">Edit</a>
                        
                        <form action="{{ route('laporan.destroy', $laporan->id) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button class="text-red-500 hover:underline" onclick="return confirm('Yakin mau hapus laporan ini?')">
                                Hapus
                            </button>
                        </form>
                    </div>

                </div>
            @endforeach
        </div>
    @else
        <p>Belum ada laporan.</p>
    @endif
    

</div>
@endsection
