<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laporkuy - Welcome</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-100 text-gray-800">

    <!-- Navbar -->
    <header id="navbar" class="fixed top-0 left-0 w-full z-50 transition-all duration-300 bg-white ">
        <div class="flex justify-between items-center px-6 py-4">
            <h1 class="text-xl font-bold text-blue-600">Laporkuy</h1>
            <nav class="space-x-4 text-gray-800">
                <a href="{{ route('login') }}" class="font-medium hover:text-blue-600 transition">Login</a>
                <a href="{{ route('register') }}" class="font-medium hover:text-blue-600 transition">Register</a>
            </nav>
        </div>
    </header>

    <!-- Hero Section with Background -->
    <section 
        class="relative w-full min-h-screen bg-cover bg-center flex items-center justify-center pt-24 px-6"
        style="background-image: url('{{ asset('images/city-hero-resize.jpg') }}');">
        <!-- Overlay -->
        <div class="absolute inset-0 bg-gray-900 opacity-30 z-0"></div>

        <!-- Hero Content -->
        <div class="relative z-10 text-center px-4 text-white max-w-2xl">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-4">Selamat Datang di <span class="text-blue-400">Laporkuy</span></h2>
            <p class="text-lg md:text-xl mb-6">
            Laporkan masalah fasilitas umum di sekitar Anda dengan cepat dan mudah! Platform ini hadir untuk memudahkan warga berkontribusi dalam menjaga kota agar tetap nyaman, aman, dan layak huni. Dengan setiap laporan yang Anda kirim, Anda ikut membantu mewujudkan kota yang lebih berkelanjutan sesuai dengan misi global SDG 11.
            </p>
            <a href="{{ route('login') }}" class="inline-block bg-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition" style="background-color: #525559 !important; color: white !important;">
                Mulai Lapor
            </a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="text-center text-sm text-gray-500 py-6 bg-gray-100">
        © {{ date('Y') }} Laporkuy. All rights reserved.
    </footer>
    <!-- <script>
        document.addEventListener("DOMContentLoaded", function () {
            const navbar = document.getElementById("navbar");

            window.addEventListener("scroll", function () {
                if (window.scrollY > 50) {
                    navbar.classList.remove("bg-white");
                    navbar.classList.add("bg-gray-100", "shadow");
                } else {
                    navbar.classList.add("bg-white");
                    navbar.classList.remove("bg-gray-100", "shadow");
                }
            });
        });
    </script> -->
</body>
</html>
