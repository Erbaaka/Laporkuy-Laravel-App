<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Laporan;

class DashboardController extends Controller
{
    public function index()
    {
        $laporans = Laporan::with('user', 'kategori')->latest()->get(); 
        return view('admin.dashboard', compact('laporans'));
    }

    public function updateStatus($id, $status)
    {
        $laporan = Laporan::findOrFail($id);
        if (!in_array($status, ['baru', 'diproses', 'selesai'])) {
            return redirect()->back()->with('error', 'Status tidak valid.');
        }
    
        $laporan->status = $status;
        $laporan->save();
    
        return redirect()->back()->with('success', 'Status laporan berhasil diperbarui.');
    }
}
