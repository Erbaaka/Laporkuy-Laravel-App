

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto p-4">
    <h1 class="text-xl font-bold mb-4">Edit Laporan</h1>

    <form action="<?php echo e(route('laporan.update', $laporan->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label for="judul" class="block font-semibold mb-1">Judul</label>
            <input 
                type="text" 
                name="judul" 
                id="judul"
                value="<?php echo e(old('judul', $laporan->judul)); ?>"
                class="w-full border border-gray-300 rounded px-3 py-2"
            >
            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label for="deskripsi" class="block font-semibold mb-1">Deskripsi</label>
            <textarea 
                name="deskripsi" 
                id="deskripsi" 
                rows="5"
                class="w-full border border-gray-300 rounded px-3 py-2"
            ><?php echo e(old('deskripsi', $laporan->deskripsi)); ?></textarea>
            <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label for="lokasi" class="block font-semibold mb-1">Lokasi</label>
            <input 
                type="text" 
                name="lokasi" 
                id="lokasi"
                value="<?php echo e(old('lokasi', $laporan->lokasi)); ?>"
                class="w-full border border-gray-300 rounded px-3 py-2"
            >
            <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label for="kategori_laporan_id" class="block font-semibold mb-1">Kategori</label>
            <select name="kategori_laporan_id" id="kategori_id" class="w-full border border-gray-300 rounded px-3 py-2">
                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($kategori->id); ?>" <?php echo e($laporan->kategori_laporan_id == $kategori->id ? 'selected' : ''); ?>>
                        <?php echo e($kategori->nama); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['kategori_laporan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label for="foto" class="block font-semibold mb-1">Ganti Foto (Opsional)</label>
            <input 
                type="file" 
                name="foto" 
                id="foto"
                class="block mt-1"
            >
            <?php if($laporan->foto): ?>
                <img src="<?php echo e(asset('storage/' . $laporan->foto)); ?>" alt="Foto lama" class="w-32 mt-2" />
            <?php endif; ?>
        </div>

        <button class="bg-blue-600 text-white px-4 py-2 rounded" style="background-color: #ff0000 !important; color: white !important;">Update</button>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laporkuy\resources\views/user/laporan/edit.blade.php ENDPATH**/ ?>