

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto p-4">
    <h1 class="text-xl font-bold mb-4">Laporan Saya</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 p-2 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('laporan.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded mb-4" style="background-color: #3B82F6 !important; color: white !important;">
        + Buat Laporan Baru
    </a>
    <hr class="mb-4">
    <h2 class="text-xl font-semibold mb-2">Daftar Laporan Anda</h2>
    <hr class="mb-4">

    <?php if($laporans->count() > 0): ?>
        <div class="space-y-4">
            <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border p-4 rounded shadow">
                    <h2 class="text-lg font-semibold"><?php echo e($laporan->judul); ?></h2>
                    <p class="text-sm text-gray-600 mb-1">
                        Kategori: <?php echo e($laporan->kategori->nama); ?> | Lokasi: <?php echo e($laporan->lokasi); ?>

                    </p>
                    <p class="mb-2"><?php echo e($laporan->deskripsi); ?></p>
                    <?php if($laporan->foto): ?>
                        <img src="<?php echo e(asset('storage/' . $laporan->foto)); ?>" alt="Foto Laporan" class="w-32 mb-2">
                    <?php endif; ?>
                    <p class="text-sm font-semibold">
                        Status: 
                        <?php if($laporan->status === 'baru'): ?>
                            <span class="text-yellow-600">Baru</span>
                        <?php elseif($laporan->status === 'diproses'): ?>
                            <span class="text-blue-600">Diproses</span>
                        <?php else: ?>
                            <span class="text-green-600">Selesai</span>
                        <?php endif; ?>
                    </p>
                    <div class="flex items-center space-x-10 mt-2">
                        <a href="<?php echo e(route('laporan.edit', $laporan->id)); ?>" class="text-blue-500 hover:underline">Edit</a>
                        
                        <form action="<?php echo e(route('laporan.destroy', $laporan->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="text-red-500 hover:underline" onclick="return confirm('Yakin mau hapus laporan ini?')">
                                Hapus
                            </button>
                        </form>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <p>Belum ada laporan.</p>
    <?php endif; ?>
    

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laporkuy\resources\views/user/laporan/index.blade.php ENDPATH**/ ?>