

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Dashboard Admin</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 p-2 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="w-full border-collapse border border-gray-300">
        <thead class="bg-gray-200">
            <tr>
                <th class="border p-2">Judul</th>
                <th class="border p-2">User</th>
                <th class="border p-2">Kategori</th>
                <th class="border p-2">Foto Laporan</th>
                <th class="border p-2">Status</th>
                <th class="border p-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t">
                    <td class="border p-2"><?php echo e($laporan->judul); ?></td>
                    <td class="border p-2"><?php echo e($laporan->user->name ?? '-'); ?></td>
                    <td class="border p-2"><?php echo e($laporan->kategori->nama ?? '-'); ?></td>
                    <td class="border p-2">
                        <?php if($laporan->foto): ?>
                            <img src="<?php echo e(asset('storage/' . $laporan->foto)); ?>" target="_blank" alt="Foto Laporan" class="w-20 h-20 object-cover rounded">
                        <?php else: ?>
                            <span class="text-gray-400 italic">-</span>
                        <?php endif; ?>
                    </td>
                    <td class="border p-2">
                        <span class="px-2 py-1 rounded text-sm 
                            <?php echo e($laporan->status == 'baru' ? 'bg-yellow-200 text-yellow-800' : ''); ?>

                            <?php echo e($laporan->status == 'diproses' ? 'bg-blue-200 text-blue-800' : ''); ?>

                            <?php echo e($laporan->status == 'selesai' ? 'bg-green-200 text-green-800' : ''); ?>">
                            <?php echo e(ucfirst($laporan->status)); ?>

                        </span>
                    </td>
                    <td class="border p-2">
                        <div class="flex space-x-2">
                            <form action="<?php echo e(route('admin.laporan.updateStatus', ['id' => $laporan->id, 'status' => 'diproses'])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="inline-block bg-blue-500 font-semibold text-white px-2 py-1 rounded-full text-sm shadow"
                                    style="background-color: #3B82F6 !important; color: white !important;">
                                    Proses
                                </button>
                            </form>

                            <form action="<?php echo e(route('admin.laporan.updateStatus', ['id' => $laporan->id, 'status' => 'selesai'])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="inline-block bg-green-100 text-green-800 font-semibold px-3 py-1 text-sm rounded-full shadow"
                                    style="background-color: #22C55E !important; color: white !important;">
                                    Selesai
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laporkuy\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>