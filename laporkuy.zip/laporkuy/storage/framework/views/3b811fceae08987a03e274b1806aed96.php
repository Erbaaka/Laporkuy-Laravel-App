

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto p-4">
    <a href="<?php echo e(route('laporan.index')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded mb-4" style="background-color: #ff0000 !important; color: white !important;">
        <- Kembali ke Halaman Laporan
    </a>
    <hr class="mb-4">

    <h1 class="text-xl font-bold mb-4">Buat Laporan</h1>
    <form action="<?php echo e(route('laporan.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="judul" class="block font-medium">Judul</label>
            <input type="text" name="judul" class="w-full border rounded p-2" required>
        </div>

        <div class="mb-3">
            <label for="kategori_laporan_id" class="block font-medium">Kategori</label>
            <select name="kategori_laporan_id" class="w-full border rounded p-2" required>
                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="deskripsi" class="block font-medium">Deskripsi</label>
            <textarea name="deskripsi" class="w-full border rounded p-2" rows="4" required></textarea>
        </div>

        <div class="mb-3">
            <label for="lokasi" class="block font-medium">Lokasi</label>
            <input type="text" name="lokasi" class="w-full border rounded p-2" required>
        </div>

        <div class="mb-3">
            <label for="foto" class="block font-medium">Foto (opsional)</label>
            <input type="file" name="foto" class="w-full border p-2">
        </div>
        <hr class="mb-4">
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded" style="background-color: #3B82F6 !important; color: white !important;">Kirim Laporan</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laporkuy\resources\views/user/laporan/create.blade.php ENDPATH**/ ?>