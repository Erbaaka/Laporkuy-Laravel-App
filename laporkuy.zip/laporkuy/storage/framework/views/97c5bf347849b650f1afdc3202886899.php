<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-100 text-gray-900">
    <div class="min-h-screen">
        <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="py-6">
            <div class="max-w-7xl mx-auto px-4">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\laporkuy\resources\views/layouts/app.blade.php ENDPATH**/ ?>