@extends('layouts.app')

@section('content')
<div class="max-w-xl mx-auto p-4">
    <a href="{{ route('laporan.index') }}" class="bg-blue-600 text-white px-4 py-2 rounded mb-4" style="background-color: #ff0000 !important;">
        ← Kembali ke Halaman Laporan
    </a>
    <hr class="mb-4">

    <h1 class="text-xl font-bold mb-4">Buat Laporan</h1>
    <form action="{{ route('laporan.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="mb-3">
            <label for="judul" class="block font-medium">Judul</label>
            <input type="text" name="judul" class="w-full border rounded p-2" required>
        </div>

        <div class="mb-3">
            <label for="kategori_laporan_id" class="block font-medium">Kategori</label>
            <select name="kategori_laporan_id" class="w-full border rounded p-2" required>
                @foreach($kategoris as $kategori)
                    <option value="{{ $kategori->id }}">{{ $kategori->nama }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="deskripsi" class="block font-medium">Deskripsi</label>
            <textarea name="deskripsi" class="w-full border rounded p-2" rows="4" required></textarea>
        </div>

        <div class="mb-3">
            <label for="lokasi" class="block font-medium">Detail Lokasi</label>
            <input type="text" name="lokasi" class="w-full border rounded p-2" required>
        </div>

        <div class="mb-3">
            <label class="block font-medium mb-1">Alamat Lokasi (Nominatim API)</label>
            <input type="text" id="searchBox" class="w-full border rounded p-2" placeholder="Contoh: Monas, Jakarta">
        </div>

        <!-- 🌍 Peta -->
        <div class="mb-3">
            <label class="block font-medium mb-1">Pilih Lokasi di Peta</label>
            <div id="map" style="height: 300px;"></div>
        </div>

        <!-- 📍 Koordinat -->
        <div class="grid grid-cols-2 gap-4 mb-3">
            <div>
                <label for="latitude" class="block font-medium">Latitude</label>
                <input type="text" name="latitude" id="latitude" class="w-full border rounded p-2" readonly>
            </div>
            <div>
                <label for="longitude" class="block font-medium">Longitude</label>
                <input type="text" name="longitude" id="longitude" class="w-full border rounded p-2" readonly>
            </div>
        </div>

        <div class="mb-3">
            <label for="foto" class="block font-medium">Foto (opsional)</label>
            <input type="file" name="foto" class="w-full border p-2">
        </div>

        <hr class="mb-4">
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">
            Kirim Laporan
        </button>
    </form>
</div>

<!-- Leaflet JS & CSS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<!-- Inisialisasi Peta -->
<script>
    const map = L.map('map').setView([-6.200000, 106.816666], 13); // Default: Jakarta
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>'
    }).addTo(map);

    const marker = L.marker([-6.200000, 106.816666], { draggable: true }).addTo(map);

    // Update input hidden saat marker digeser
    function updateLatLng(lat, lng) {
        document.getElementById('latitude').value = lat;
        document.getElementById('longitude').value = lng;
    }

    // Klik map → pindah marker
    map.on('click', function(e) {
        const { lat, lng } = e.latlng;
        marker.setLatLng([lat, lng]);
        updateLatLng(lat, lng);
    });

    // Geser marker manual
    marker.on('dragend', function(e) {
        const { lat, lng } = e.target.getLatLng();
        updateLatLng(lat, lng);
    });

    // Search lokasi via Nominatim
    document.getElementById('searchBox').addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();

            const query = e.target.value;
            if (!query) return;

            fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
                .then(res => res.json())
                .then(data => {
                    if (data.length === 0) {
                        alert('Lokasi tidak ditemukan.');
                        return;
                    }

                    const { lat, lon } = data[0];
                    const latNum = parseFloat(lat);
                    const lonNum = parseFloat(lon);

                    map.setView([latNum, lonNum], 17);
                    marker.setLatLng([latNum, lonNum]);
                    updateLatLng(latNum, lonNum);
                })
                .catch(err => {
                    console.error(err);
                    alert('Terjadi kesalahan saat mencari lokasi.');
                });
        }
    });

    // Set nilai awal ke input hidden
    updateLatLng(-6.200000, 106.816666);
</script>
@endsection
