@extends('layouts.app')

@section('content')
<div class="max-w-xl mx-auto p-4">
    <h1 class="text-xl font-bold mb-4">Edit Laporan</h1>

    <form action="{{ route('laporan.update', $laporan->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="mb-4">
            <label for="judul" class="block font-semibold mb-1">Judul</label>
            <input 
                type="text" 
                name="judul" 
                id="judul"
                value="{{ old('judul', $laporan->judul) }}"
                class="w-full border border-gray-300 rounded px-3 py-2"
            >
            @error('judul')
                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="deskripsi" class="block font-semibold mb-1">Deskripsi</label>
            <textarea 
                name="deskripsi" 
                id="deskripsi" 
                rows="5"
                class="w-full border border-gray-300 rounded px-3 py-2"
            >{{ old('deskripsi', $laporan->deskripsi) }}</textarea>
            @error('deskripsi')
                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="lokasi" class="block font-semibold mb-1">Lokasi</label>
            <input 
                type="text" 
                name="lokasi" 
                id="lokasi"
                value="{{ old('lokasi', $laporan->lokasi) }}"
                class="w-full border border-gray-300 rounded px-3 py-2"
            >
            @error('lokasi')
                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="kategori_laporan_id" class="block font-semibold mb-1">Kategori</label>
            <select name="kategori_laporan_id" id="kategori_id" class="w-full border border-gray-300 rounded px-3 py-2">
                @foreach($kategoris as $kategori)
                <option value="{{ $kategori->id }}" {{ $laporan->kategori_laporan_id == $kategori->id ? 'selected' : '' }}>
                        {{ $kategori->nama }}
                    </option>
                @endforeach
            </select>
            @error('kategori_laporan_id')
                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="foto" class="block font-semibold mb-1">Ganti Foto (Opsional)</label>
            <input 
                type="file" 
                name="foto" 
                id="foto"
                class="block mt-1"
            >
            @if($laporan->foto)
                <img src="{{ asset('storage/' . $laporan->foto) }}" alt="Foto lama" class="w-32 mt-2" />
            @endif
        </div>

        <button class="bg-blue-600 text-white px-4 py-2 rounded" style="background-color: #ff0000 !important; color: white !important;">Update</button>
    </form>
</div>

@endsection
