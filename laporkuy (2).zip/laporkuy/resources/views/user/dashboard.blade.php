@extends('layouts.app')

@section('content')
    <h1 class="text-xl font-bold">Halo, {{ Auth::user()->name }}!</h1>
    <p class="mt-2">Selamat datang di halaman pengguna. Kamu bisa mengelola laporanmu di sini.</p>
    <hr class="mb-4">
    <a href="{{ route('laporan.index') }}" class="bg-blue-600 text-white px-4 py-2 rounded mb-4" style="background-color: #0a41f5 !important; color: white !important;">
        Lihat Laporan Saya
    </a>
@endsection
