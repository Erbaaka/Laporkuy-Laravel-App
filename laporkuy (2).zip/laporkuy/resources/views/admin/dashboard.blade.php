@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Dashboard Admin</h1>

    @if(session('success'))
        <div class="bg-green-100 text-green-800 p-2 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <table class="w-full border-collapse border border-gray-300">
        <thead class="bg-gray-200">
            <tr>
                <th class="border p-2">Judul</th>
                <th class="border p-2">User</th>
                <th class="border p-2">Kategori</th>
                <th class="border p-2">Foto Laporan</th>
                <th class="border p-2">Status</th>
                <th class="border p-2">Lokasi</th>
                <th class="border p-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($laporans as $laporan)
                <tr class="border-t">
                    <td class="border p-2">{{ $laporan->judul }}</td>
                    <td class="border p-2">{{ $laporan->user->name ?? '-' }}</td>
                    <td class="border p-2">{{ $laporan->kategori->nama ?? '-' }}</td>
                    <td class="border p-2">
                        @if($laporan->foto)
                            <img src="{{ asset('storage/' . $laporan->foto) }}" target="_blank" alt="Foto Laporan" class="w-20 h-20 object-cover rounded">
                        @else
                            <span class="text-gray-400 italic">-</span>
                        @endif
                    </td>
                    <td class="border p-2">
                        <span class="px-2 py-1 rounded text-sm 
                            {{ $laporan->status == 'baru' ? 'bg-yellow-200 text-yellow-800' : '' }}
                            {{ $laporan->status == 'diproses' ? 'bg-blue-200 text-blue-800' : '' }}
                            {{ $laporan->status == 'selesai' ? 'bg-green-200 text-green-800' : '' }}">
                            {{ ucfirst($laporan->status) }}
                        </span>
                    </td>

                    <td class="border p-2 text-center">
                        @if ($laporan->latitude && $laporan->longitude)
                            <button type="button"
                                onclick="openMapModal({{ $laporan->id }}, {{ $laporan->latitude }}, {{ $laporan->longitude }}, '{{ $laporan->judul }}', '{{ $laporan->kategori->nama ?? '-' }}')"
                                class="inline-block bg-indigo-500 text-white px-2 py-1 rounded-full text-sm shadow"
                                style="background-color: #fa2d1e !important; color: white !important;">
                                Detail Lokasi 
                            </button>
                        @else
                            <span class="text-gray-400 italic">-</span>
                        @endif
                    </td>

                    <td class="border p-2">
                        <div class="flex space-x-2">
                            <form action="{{ route('admin.laporan.updateStatus', ['id' => $laporan->id, 'status' => 'diproses']) }}" method="POST">
                                @csrf
                                <button type="submit" class="inline-block bg-blue-500 font-semibold text-white px-2 py-1 rounded-full text-sm shadow"
                                    style="background-color: #3B82F6 !important; color: white !important;">
                                    Proses
                                </button>
                            </form>

                            <form action="{{ route('admin.laporan.updateStatus', ['id' => $laporan->id, 'status' => 'selesai']) }}" method="POST">
                                @csrf
                                <button type="submit" class="inline-block bg-green-100 text-green-800 font-semibold px-3 py-1 text-sm rounded-full shadow"
                                    style="background-color: #22C55E !important; color: white !important;">
                                    Selesai
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
<!-- Modal Map -->
<div id="mapModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white p-4 rounded shadow w-[90%] md:w-[600px] relative">
        <button onclick="closeMapModal()" class="absolute top-2 right-2 text-red-500 font-bold">X</button>
        <br>
        <h2 class="text-lg font-semibold mb-2">Lokasi Laporan</h2>
        <div id="mapContainer" class="rounded" style="height: 400px;"></div>
    </div>
</div>
<!-- Leaflet -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>
    let mapInstance = null;

    function openMapModal(id, lat, lng, judul, kategori) {
        if (!lat || !lng) {
            alert('Lokasi belum tersedia untuk laporan ini.');
            return;
        }

        document.getElementById('mapModal').classList.remove('hidden');

        setTimeout(() => {
            // Bersihkan map sebelumnya
            if (mapInstance !== null) {
                mapInstance.remove();
            }

            mapInstance = L.map('mapContainer').setView([lat, lng], 16);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(mapInstance);

            L.marker([lat, lng])
                .addTo(mapInstance)
                .bindPopup(`<strong>${judul}</strong><br>Kategori: ${kategori}`)
                .openPopup();
        }, 300);
    }

    function closeMapModal() {
        document.getElementById('mapModal').classList.add('hidden');
        if (mapInstance !== null) {
            mapInstance.remove();
            mapInstance = null;
        }
    }
</script>

@endsection
