

<?php $__env->startSection('content'); ?>
    <h1 class="text-xl font-bold">Halo, <?php echo e(Auth::user()->name); ?>!</h1>
    <p class="mt-2">Selamat datang di halaman pengguna. Kamu bisa mengelola laporanmu di sini.</p>
    <hr class="mb-4">
    <a href="<?php echo e(route('laporan.index')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded mb-4" style="background-color: #0a41f5 !important; color: white !important;">
        Lihat Laporan Saya
    </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laporkuy\resources\views/user/dashboard.blade.php ENDPATH**/ ?>