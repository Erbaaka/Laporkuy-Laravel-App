<?php

namespace App\Http\Controllers;

use App\Models\Laporan;
use App\Models\KategoriLaporan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class LaporanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $laporans = Laporan::where('user_id', Auth::id())->latest()->get();
        return view('user.laporan.index', compact('laporans'));
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $kategoris = KategoriLaporan::all();
        return view('user.laporan.create', compact('kategoris'));
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'judul' => 'required',
            'deskripsi' => 'required',
            'lokasi' => 'required',
            'kategori_laporan_id' => 'required|exists:kategori_laporans,id',
            'foto' => 'nullable|image|max:2048',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
        ]);

        $laporan = new Laporan();
        $laporan->judul = $request->judul;
        $laporan->deskripsi = $request->deskripsi;
        $laporan->lokasi = $request->lokasi;
        $laporan->kategori_laporan_id = $request->kategori_laporan_id;
        $laporan->user_id = Auth::id();
        $laporan->status = 'baru';
        $laporan->latitude = $request->latitude;
        $laporan->longitude = $request->longitude;

        if ($request->hasFile('foto')) {
            $laporan->foto = $request->file('foto')->store('foto-laporan', 'public');
        }

        $laporan->save();

        return redirect()->route('laporan.index')->with('success', 'Laporan berhasil dikirim!');
    }


    /**
     * Display the specified resource.
     */
    public function show(Laporan $laporan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Laporan $laporan)
    {
        if ($laporan->user_id !== Auth::id()) {
            abort(403);
        }

        $kategoris = KategoriLaporan::all();
        return view('user.laporan.edit', compact('laporan', 'kategoris'));
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Laporan $laporan)
    {
        if ($laporan->user_id !== Auth::id()) {
            abort(403);
        }

        $request->validate([
            'judul' => 'required',
            'deskripsi' => 'required',
            'lokasi' => 'required',
            'kategori_laporan_id' => 'required|exists:kategori_laporans,id',
            'foto' => 'nullable|image|max:2048',
        ]);

        $laporan->update([
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi,
            'lokasi' => $request->lokasi,
            'kategori_laporan_id' => $request->kategori_laporan_id,
        ]);

        if ($request->hasFile('foto')) {
            // Hapus foto lama
            if ($laporan->foto) {
                Storage::disk('public')->delete($laporan->foto);
            }
            $laporan->foto = $request->file('foto')->store('foto-laporan', 'public');
            $laporan->save();
        }

        return redirect()->route('laporan.index')->with('success', 'Laporan berhasil diperbarui!');
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Laporan $laporan)
    {
        if ($laporan->user_id !== Auth::id()) {
            abort(403);
        }

        if ($laporan->foto) {
            Storage::disk('public')->delete($laporan->foto);
        }

        $laporan->delete();

        return back()->with('success', 'Laporan berhasil dihapus!');
    }
}
